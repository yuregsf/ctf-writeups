// Package prometheus provides a module which collects metrics and exposes them
// via an HTTP route.
//
// See: https://prometheus.io/.
package prometheus
