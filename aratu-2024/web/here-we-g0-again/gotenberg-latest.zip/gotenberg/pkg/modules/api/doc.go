// Package api provides a module which is an HTTP server. Other modules may
// add multipart/form-data routes, middlewares, and health checks.
package api
