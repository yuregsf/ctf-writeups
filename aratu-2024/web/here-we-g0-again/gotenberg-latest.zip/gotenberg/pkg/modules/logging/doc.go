// Package logging provides a module which creates a zap.Logger instance for
// other modules.
package logging
