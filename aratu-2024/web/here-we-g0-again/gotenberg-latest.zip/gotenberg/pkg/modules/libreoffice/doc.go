// Package libreoffice provides a module which adds a route for converting
// documents to PDF with LibreOffice.
package libreoffice
