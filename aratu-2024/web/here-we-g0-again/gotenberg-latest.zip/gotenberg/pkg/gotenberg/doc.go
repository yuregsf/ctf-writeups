// Package gotenberg provides most of the logic of the module system.
//
// caddyserver/caddy, licensed under the Apache License 2.0, has significantly
// inspired this module system.
//
// More details are available on https://caddyserver.com/.
package gotenberg
