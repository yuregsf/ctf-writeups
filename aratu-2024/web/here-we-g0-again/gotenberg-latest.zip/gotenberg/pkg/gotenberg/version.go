package gotenberg

// Version is the... version of the Gotenberg application.
var Version = "snapshot"
