#!/bin/bash

set -x

golangci-lint run