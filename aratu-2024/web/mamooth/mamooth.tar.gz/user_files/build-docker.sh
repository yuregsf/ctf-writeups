# chall sem codigo fonte/download!!!
docker build -t mamooth .; docker run -p 3000:80  mamooth:latest
